module.exports = {
    MemberCreatedEvent: require('./lib/MemberCreatedEvent'),
    MemberEntryViewEvent: require('./lib/MemberEntryViewEvent'),
    MemberSubscribeEvent: require('./lib/MemberSubscribeEvent'),
    MemberUnsubscribeEvent: require('./lib/MemberUnsubscribeEvent'),
    MemberSignupEvent: require('./lib/MemberSignupEvent'),
    MemberPaidConverstionEvent: require('./lib/MemberPaidConversionEvent'),
    MemberPaidCancellationEvent: require('./lib/MemberPaidCancellationEvent'),
    MemberPageViewEvent: require('./lib/MemberPageViewEvent'),
    SubscriptionCreatedEvent: require('./lib/SubscriptionCreatedEvent'),
    MemberCommentEvent: require('./lib/MemberCommentEvent'),
    SubscriptionCancelledEvent: require('./lib/SubscriptionCancelledEvent'),
    MemberLinkClickEvent: require('./lib/MemberLinkClickEvent')
};
